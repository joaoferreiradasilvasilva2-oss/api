/**
 * GhostsPays Gateway API Integration
 * 
 * This module provides functions to interact with the GhostsPays payment gateway.
 * Credentials are stored securely in environment variables.
 */

const API_BASE_URL = "https://api.ghostspaysv2.com/functions/v1";

function getAuthHeader(): string {
  const secretKey = process.env.GHOSTSPAYS_SECRET_KEY;
  const companyId = process.env.GHOSTSPAYS_COMPANY_ID;

  if (!secretKey || !companyId) {
    throw new Error(
      "GhostsPays credentials not configured. Please set GHOSTSPAYS_SECRET_KEY and GHOSTSPAYS_COMPANY_ID environment variables."
    );
  }

  const credentials = Buffer.from(`${secretKey}:${companyId}`).toString("base64");
  return `Basic ${credentials}`;
}

interface GhostsPaysResponse<T = unknown> {
  success: boolean;
  data?: T;
  error?: string;
}

async function apiRequest<T>(
  endpoint: string,
  method: "GET" | "POST" | "PUT" | "DELETE" = "GET",
  body?: Record<string, unknown>
): Promise<GhostsPaysResponse<T>> {
  try {
    console.log("[v0] GhostsPays API Request:", {
      url: `${API_BASE_URL}${endpoint}`,
      method,
      body,
    });

    const response = await fetch(`${API_BASE_URL}${endpoint}`, {
      method,
      headers: {
        Authorization: getAuthHeader(),
        "Content-Type": "application/json",
      },
      body: body ? JSON.stringify(body) : undefined,
    });

    const data = await response.json();

    console.log("[v0] GhostsPays API Response:", {
      status: response.status,
      data,
    });

    if (!response.ok) {
      return {
        success: false,
        error: data.message || data.error || JSON.stringify(data) || `Request failed with status ${response.status}`,
      };
    }

    return {
      success: true,
      data,
    };
  } catch (error) {
    console.error("[v0] GhostsPays API Error:", error);
    return {
      success: false,
      error: error instanceof Error ? error.message : "Unknown error occurred",
    };
  }
}

// ============================================
// PIX Payment Functions
// ============================================

export interface PixPaymentRequest {
  amount: number;
  customer: {
    name: string;
    email: string;
    document: string; // CPF or CNPJ
    phone?: string;
  };
  externalId?: string;
  description?: string;
  expiresIn?: number; // Expiration time in seconds
}

export interface PixPaymentResponse {
  id: string;
  status: string;
  amount: number;
  pix: {
    qrcode: string;
    qrcodeBase64: string;
    expirationDate: string;
  };
  secureUrl: string;
}

/**
 * Create a PIX payment
 */
export async function createPixPayment(data: PixPaymentRequest) {
  // Format document - remove non-numeric characters
  const documentNumber = data.customer.document.replace(/\D/g, "");
  const documentType = documentNumber.length <= 11 ? "CPF" : "CNPJ";

  return apiRequest<PixPaymentResponse>("/transactions", "POST", {
    paymentMethod: "PIX",
    amount: Math.round(data.amount * 100), // Convert to cents
    customer: {
      name: data.customer.name,
      email: data.customer.email,
      phone: data.customer.phone || "11999999999",
      document: {
        number: documentNumber,
        type: documentType,
      },
    },
    items: [
      {
        title: data.description || "Pagamento PIX",
        unitPrice: Math.round(data.amount * 100),
        quantity: 1,
        tangible: false,
      },
    ],
  });
}

// ============================================
// Transaction Functions
// ============================================

export interface Transaction {
  id: string;
  status: string;
  amount: number;
  type: string;
  createdAt: string;
  customer: {
    name: string;
    email: string;
    document: string;
  };
}

/**
 * Get transaction by ID
 */
export async function getTransaction(transactionId: string) {
  return apiRequest<Transaction>(`/transactions/${transactionId}`);
}

/**
 * List all transactions
 */
export async function listTransactions(params?: {
  page?: number;
  limit?: number;
  status?: string;
}) {
  const searchParams = new URLSearchParams();
  if (params?.page) searchParams.set("page", params.page.toString());
  if (params?.limit) searchParams.set("limit", params.limit.toString());
  if (params?.status) searchParams.set("status", params.status);

  const query = searchParams.toString();
  return apiRequest<{ transactions: Transaction[]; total: number }>(
    `/transactions${query ? `?${query}` : ""}`
  );
}

// ============================================
// Webhook Verification
// ============================================

/**
 * Verify webhook signature (implement based on GhostsPays documentation)
 */
export function verifyWebhookSignature(
  payload: string,
  signature: string
): boolean {
  // TODO: Implement signature verification based on GhostsPays webhook documentation
  // This typically involves HMAC comparison with a webhook secret
  console.warn("Webhook signature verification not yet implemented");
  return true;
}

// ============================================
// Refund Functions
// ============================================

export interface RefundRequest {
  transactionId: string;
  amount?: number; // Optional for partial refunds
  reason?: string;
}

/**
 * Create a refund for a transaction
 */
export async function createRefund(data: RefundRequest) {
  return apiRequest(`/transactions/${data.transactionId}/refund`, "POST", {
    amount: data.amount,
    reason: data.reason,
  });
}
