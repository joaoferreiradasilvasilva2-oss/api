import { NextRequest, NextResponse } from "next/server";
import { createPixPayment, type PixPaymentRequest } from "@/lib/ghostspays";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();

    // Validate required fields
    const { amount, customer } = body as PixPaymentRequest;

    if (!amount || amount <= 0) {
      return NextResponse.json(
        { error: "Invalid amount. Must be greater than 0." },
        { status: 400 }
      );
    }

    if (!customer?.name || !customer?.email || !customer?.document) {
      return NextResponse.json(
        { error: "Customer name, email, and document (CPF/CNPJ) are required." },
        { status: 400 }
      );
    }

    // Create PIX payment
    const result = await createPixPayment(body);

    if (!result.success) {
      return NextResponse.json(
        { error: result.error },
        { status: 500 }
      );
    }

    return NextResponse.json(result.data);
  } catch (error) {
    console.error("Error creating PIX payment:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}
