import { NextRequest, NextResponse } from "next/server";
import { verifyWebhookSignature, getTransaction } from "@/lib/ghostspays";

export async function POST(request: NextRequest) {
  try {
    const body = await request.text();
    const signature = request.headers.get("x-ghostspays-signature") || "";

    // Verify webhook signature
    if (!verifyWebhookSignature(body, signature)) {
      return NextResponse.json(
        { error: "Invalid signature" },
        { status: 401 }
      );
    }

    const payload = JSON.parse(body);
    const { event, transactionId } = payload;

    console.log(`[Webhook] Received event: ${event} for transaction: ${transactionId}`);

    // Handle different webhook events
    switch (event) {
      case "payment.confirmed":
        // Payment was confirmed - update your database, send confirmation email, etc.
        console.log(`Payment ${transactionId} confirmed`);
        // TODO: Add your business logic here
        break;

      case "payment.failed":
        // Payment failed
        console.log(`Payment ${transactionId} failed`);
        // TODO: Add your business logic here
        break;

      case "payment.expired":
        // Payment expired
        console.log(`Payment ${transactionId} expired`);
        // TODO: Add your business logic here
        break;

      case "refund.completed":
        // Refund completed
        console.log(`Refund for ${transactionId} completed`);
        // TODO: Add your business logic here
        break;

      default:
        console.log(`Unhandled event type: ${event}`);
    }

    // Optionally fetch full transaction details
    if (transactionId) {
      const transaction = await getTransaction(transactionId);
      if (transaction.success) {
        console.log("Transaction details:", transaction.data);
      }
    }

    return NextResponse.json({ received: true });
  } catch (error) {
    console.error("Webhook error:", error);
    return NextResponse.json(
      { error: "Webhook processing failed" },
      { status: 500 }
    );
  }
}
