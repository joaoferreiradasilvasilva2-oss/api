"use client";

import React, { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Copy, CheckCircle2 } from "lucide-react";
import QRCode from "qrcode";

interface PaymentResult {
  id: string;
  pix?: {
    qrcode?: string;
    qrcodeBase64?: string;
    qrCode?: string;
    qrCodeBase64?: string;
    emv?: string;
    expirationDate?: string;
  };
  secureUrl?: string;
  status: string;
  amount: number;
}

const FIXED_AMOUNT = 24.90;

const RANDOM_FIRST_NAMES = [
  "Lucas", "Gabriel", "Rafael", "Bruno", "Felipe", "Matheus", "Gustavo", "Pedro",
  "Joao", "Carlos", "Andre", "Marcos", "Ricardo", "Fernando", "Diego", "Thiago",
  "Ana", "Maria", "Juliana", "Camila", "Fernanda", "Patricia", "Amanda", "Bruna",
  "Larissa", "Leticia", "Carolina", "Mariana", "Beatriz", "Gabriela", "Isabela", "Renata"
];

const RANDOM_LAST_NAMES = [
  "Silva", "Santos", "Oliveira", "Souza", "Rodrigues", "Ferreira", "Alves", "Pereira",
  "Lima", "Gomes", "Costa", "Ribeiro", "Martins", "Carvalho", "Almeida", "Lopes",
  "Soares", "Fernandes", "Vieira", "Barbosa", "Rocha", "Dias", "Nascimento", "Andrade"
];

function generateRandomName(): string {
  const firstName = RANDOM_FIRST_NAMES[Math.floor(Math.random() * RANDOM_FIRST_NAMES.length)];
  const lastName = RANDOM_LAST_NAMES[Math.floor(Math.random() * RANDOM_LAST_NAMES.length)];
  return `${firstName} ${lastName}`;
}

function generateRandomCPF(): string {
  const random = () => Math.floor(Math.random() * 9);
  const n = Array.from({ length: 9 }, random);
  
  const d1 = ((n[0] * 10 + n[1] * 9 + n[2] * 8 + n[3] * 7 + n[4] * 6 + n[5] * 5 + n[6] * 4 + n[7] * 3 + n[8] * 2) * 10) % 11 % 10;
  const d2 = ((n[0] * 11 + n[1] * 10 + n[2] * 9 + n[3] * 8 + n[4] * 7 + n[5] * 6 + n[6] * 5 + n[7] * 4 + n[8] * 3 + d1 * 2) * 10) % 11 % 10;
  
  return `${n.join("")}${d1}${d2}`;
}

function generateRandomEmail(name: string): string {
  const cleanName = name.toLowerCase().replace(" ", ".").normalize("NFD").replace(/[\u0300-\u036f]/g, "");
  const domains = ["gmail.com", "hotmail.com", "outlook.com", "yahoo.com.br"];
  const domain = domains[Math.floor(Math.random() * domains.length)];
  const randomNum = Math.floor(Math.random() * 999);
  return `${cleanName}${randomNum}@${domain}`;
}

const instructions = [
  "Abra o app do seu banco",
  'Na secao PIX, selecione "Pix Copia e Cola"',
  "Cole o codigo copiado",
  "Confirme o pagamento",
];

export default function PaymentPage() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [paymentResult, setPaymentResult] = useState<PaymentResult | null>(null);
  const [copied, setCopied] = useState(false);
  const [qrCodeDataUrl, setQrCodeDataUrl] = useState<string | null>(null);

  const pixCode = paymentResult?.pix?.qrcode || paymentResult?.pix?.qrCode || paymentResult?.pix?.emv || "";

  useEffect(() => {
    if (pixCode) {
      QRCode.toDataURL(pixCode, {
        width: 200,
        margin: 2,
        color: {
          dark: "#000000",
          light: "#ffffff",
        },
      })
        .then((url) => setQrCodeDataUrl(url))
        .catch((err) => console.error("Error generating QR code:", err));
    }
  }, [pixCode]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    const randomName = generateRandomName();
    const randomCPF = generateRandomCPF();
    const randomEmail = generateRandomEmail(randomName);

    try {
      const response = await fetch("/api/payments/pix", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          amount: FIXED_AMOUNT,
          customer: {
            name: randomName,
            email: randomEmail,
            document: randomCPF,
          },
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || "Erro ao criar pagamento");
      }

      setPaymentResult(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Erro desconhecido");
    } finally {
      setLoading(false);
    }
  };

  const copyPixCode = async () => {
    if (pixCode) {
      await navigator.clipboard.writeText(pixCode);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  if (paymentResult) {
    return (
      <main className="min-h-screen bg-background flex items-center justify-center p-4">
        <div className="w-full max-w-4xl">
          <h1 className="text-2xl font-semibold text-center text-foreground mb-8">
            Finalize seu pagamento
          </h1>
          
          <div className="flex flex-col md:flex-row gap-8 md:gap-12">
            {/* Left side - PIX Code and Instructions */}
            <div className="flex-1 space-y-6">
              <div className="space-y-2">
                <Label className="text-sm font-medium text-foreground">Codigo PIX</Label>
                <div className="p-3 bg-muted border border-border rounded-md">
                  <p className="font-mono text-xs text-foreground break-all leading-relaxed">
                    {pixCode || "Codigo nao disponivel"}
                  </p>
                </div>
              </div>

              <Button
                onClick={copyPixCode}
                className="w-full bg-foreground text-background hover:bg-foreground/90"
                disabled={!pixCode}
              >
                <Copy className="w-4 h-4 mr-2" />
                {copied ? "Codigo copiado!" : "Copiar codigo PIX"}
              </Button>

              <div className="space-y-4">
                <h3 className="font-medium text-foreground">Instrucoes</h3>
                <div className="space-y-3">
                  {instructions.map((instruction, index) => (
                    <div key={index} className="flex items-start gap-3">
                      <div className="flex-shrink-0 w-6 h-6 bg-muted rounded flex items-center justify-center">
                        <span className="text-xs font-medium text-foreground">{index + 1}</span>
                      </div>
                      <p className="text-sm text-foreground pt-0.5">{instruction}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Right side - QR Code */}
            <div className="flex flex-col items-center justify-start space-y-4">
              <div className="bg-background p-4 rounded-lg border border-border">
                {qrCodeDataUrl ? (
                  <img
                    src={qrCodeDataUrl || "/placeholder.svg"}
                    alt="QR Code PIX"
                    className="w-48 h-48"
                  />
                ) : (
                  <div className="w-48 h-48 flex items-center justify-center bg-muted rounded">
                    <p className="text-sm text-muted-foreground text-center p-4">
                      Gerando QR Code...
                    </p>
                  </div>
                )}
              </div>
              <p className="text-sm text-primary text-center max-w-[200px]">
                Escaneie o codigo QR com a camera do seu celular
              </p>
              
              <div className="flex items-center gap-3 w-full max-w-[200px]">
                <div className="flex-1 h-px bg-border" />
                <span className="text-sm text-muted-foreground">Ou</span>
                <div className="flex-1 h-px bg-border" />
              </div>

              <p className="text-xs text-muted-foreground text-center">
                Copie o codigo e cole no app do banco
              </p>
            </div>
          </div>

          <div className="mt-8 flex justify-center">
            <Button
              onClick={() => {
                setPaymentResult(null);
                setQrCodeDataUrl(null);
                setCopied(false);
              }}
              variant="outline"
              className="bg-transparent"
            >
              Novo Pagamento
            </Button>
          </div>
        </div>
      </main>
    );
  }

  return (
    <main className="min-h-screen bg-background flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle className="text-2xl">Pagamento PIX</CardTitle>
          <CardDescription>
            Clique no botao para gerar seu pagamento
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label>Valor (R$)</Label>
              <Input
                value="24,90"
                readOnly
                className="bg-muted font-medium"
              />
            </div>

            {error && (
              <div className="p-3 bg-destructive/10 border border-destructive/20 rounded-lg">
                <p className="text-sm text-destructive">{error}</p>
              </div>
            )}

            <Button type="submit" className="w-full" disabled={loading}>
              {loading ? "Gerando..." : "Gerar Pagamento PIX"}
            </Button>
          </form>
        </CardContent>
      </Card>
    </main>
  );
}
